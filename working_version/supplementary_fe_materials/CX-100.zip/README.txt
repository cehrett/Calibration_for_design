airfoils/ - Collection of airfoil profiles used for the CX-100 blade
CX-100.nmd - NuMAD file for the CX-100
MatDBsi.txt - Material database for the blade composite layers
shell7.src - ANSYS input file to generate the geometry, mesh, apply loading, solve, save nodal displacements and rotations
.mac files - macro files used by ANSYS during geometry generation